package com.turkeymod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.turkeymod.TurkeyMod;
import com.turkeymod.entity.TurkeyEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class TurkeyModel extends EntityModel<TurkeyEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(TurkeyMod.MODID, "turkey"), "main");

    private final ModelPart root, head, body, tail, rightWing, leftWing, rightLeg, leftLeg;

    public TurkeyModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.tail = root.getChild("tail");
        this.rightWing = root.getChild("right_wing");
        this.leftWing = root.getChild("left_wing");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = mesh.getRoot();

        p.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-4, -3, -5, 8, 7, 10), PartPose.offset(0, 14, 0));

        // head + neck + beak + wattle share one pivot
        PartDefinition head = p.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(36, 0).addBox(-1.5F, 0, -1.5F, 3, 7, 3)          // neck
                .texOffs(0, 18).addBox(-2, -4, -2, 4, 4, 4)               // head
                .texOffs(18, 18).addBox(-1, -2, -4, 2, 1, 2)              // beak
                .texOffs(28, 18).addBox(-0.5F, -1, -3, 1, 3, 1),          // wattle
                PartPose.offset(0, 6, -4));

        p.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(0, 48)
                .addBox(-6, -8, 0, 12, 10, 1), PartPose.offsetAndRotation(0, 13, 5, -0.3F, 0, 0));

        p.addOrReplaceChild("right_wing", CubeListBuilder.create().texOffs(0, 36)
                .addBox(-1, 0, -3, 1, 5, 6), PartPose.offset(-4, 12, 0));
        p.addOrReplaceChild("left_wing", CubeListBuilder.create().texOffs(16, 36)
                .addBox(0, 0, -3, 1, 5, 6), PartPose.offset(4, 12, 0));

        CubeListBuilder leg = CubeListBuilder.create()
                .texOffs(0, 28).addBox(-1, 0, -1, 2, 5, 2)
                .texOffs(10, 28).addBox(-2, 5, -3, 4, 1, 4);
        p.addOrReplaceChild("right_leg", leg, PartPose.offset(-2, 18, 1));
        p.addOrReplaceChild("left_leg", leg, PartPose.offset(2, 18, 1));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(TurkeyEntity e, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        head.xRot = headPitch * ((float) Math.PI / 180F);
        head.yRot = netHeadYaw * ((float) Math.PI / 180F);

        boolean sitting = e.isInSittingPose();
        root.y = sitting ? 5.0F : 0.0F;
        rightLeg.visible = !sitting;
        leftLeg.visible = !sitting;

        rightLeg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        leftLeg.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.4F * limbSwingAmount;

        float flap = e.onGround() ? 0.0F : (Mth.sin(ageInTicks * 1.3F) * 0.8F + 0.8F);
        rightWing.zRot = flap;
        leftWing.zRot = -flap;
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buffer, int light, int overlay, int color) {
        root.render(pose, buffer, light, overlay, color);
    }
}
