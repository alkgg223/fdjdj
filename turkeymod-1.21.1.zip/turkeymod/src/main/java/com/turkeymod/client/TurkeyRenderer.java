package com.turkeymod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.turkeymod.TurkeyMod;
import com.turkeymod.entity.TurkeyEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class TurkeyRenderer extends MobRenderer<TurkeyEntity, TurkeyModel> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(TurkeyMod.MODID, "textures/entity/turkey.png");

    public TurkeyRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new TurkeyModel(ctx.bakeLayer(TurkeyModel.LAYER)), 0.4F);
    }

    @Override
    public ResourceLocation getTextureLocation(TurkeyEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(TurkeyEntity entity, PoseStack pose, float partialTick) {
        if (entity.isBaby()) pose.scale(0.5F, 0.5F, 0.5F);
    }
}
