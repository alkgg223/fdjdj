package com.turkeymod.registry;

import com.turkeymod.TurkeyMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(Registries.ITEM, TurkeyMod.MODID);

    public static final DeferredHolder<Item, DeferredSpawnEggItem> TURKEY_SPAWN_EGG =
            ITEMS.register("turkey_spawn_egg", () ->
                    new DeferredSpawnEggItem(ModEntities.TURKEY, 0x6B4423, 0xC9302C, new Item.Properties()));
}
